clear all; %Pulisce il Workspace
sim('nome_file'); %Lancia la simulazione
%Il modello Simulink scrive i risultati all'interno di variabili nel Worksapce
%Esse vengono poi usate per realizzare i grafici

figure;

%Velocità East (Asse X)
plot(t, x(:,3),'bx',...
    t, y(:,3),'gd',...
    t, xhat(:,3),'ro',...
    'LineStyle','-');
title('Velocità East (Asse X)');
xlabel('Tempo [s]');
ylabel('Velocità East(Asse X) [m/s]');
legend('Reali','Misurati','Stima del filtro di Kalman','Location','Best');
axis tight;

%Per comodità non vengono riportati tutti i grafici
[...]

bdclose('nome_file'); %Chiude il modello Simulink
