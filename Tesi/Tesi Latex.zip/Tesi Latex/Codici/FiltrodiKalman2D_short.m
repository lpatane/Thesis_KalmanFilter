%Ciclo filtro di Kalman
for i = 1:n-1
    u = [misurati(i).Acceleration(1); misurati(i).Acceleration(2)];
    Y = [misurati(i).Position(1)-offset_x; misurati(i).Position(2)-offset_y; misurati(i).Velocity(1); misurati(i).Velocity(2)];
    p_est = A * p_est + B * u;
    kalman(i+1).P = A * kalman(i).P * A' + Q;
    kalman(i).K = kalman(i+1).P*H'*inv(H*kalman(i+1).P*H'+R*eye(length(A)));
    p_est = p_est + kalman(i).K * (Y - H*p_est);
    kalman(i+1).P = ( eye(length(A)) - kalman(i).K*H ) * kalman(i+1).P;
    
    stimata.x = [stimata.x; p_est(1)];
    stimata.y = [stimata.y; p_est(2)];
    stimata.vx = [stimata.vx; p_est(3)];
    stimata.vy = [stimata.vy; p_est(4)];
    
    misurata.x = [misurata.x; Y(1)];
    misurata.y = [misurata.y; Y(2)];
    misurata.vx = [misurata.vx; Y(3)];
    misurata.vy = [misurata.vy; Y(4)];
    
    ideale.x = [ideale.x; esatti(i).Position(1)];
    ideale.y = [ideale.y; esatti(i).Position(2)];
    ideale.vx = [ideale.vx; esatti(i).Velocity(1)];
    ideale.vy = [ideale.vy; esatti(i).Velocity(2)];
end
